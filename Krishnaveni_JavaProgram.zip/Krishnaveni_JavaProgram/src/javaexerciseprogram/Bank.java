package javaexerciseprogram;

public class Bank {			//Main Class file <Features of Bank>
	float getRateOfInterest()   
	{
		return 0;              
	}
}


