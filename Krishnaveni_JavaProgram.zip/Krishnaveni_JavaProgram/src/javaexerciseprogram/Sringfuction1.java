package javaexerciseprogram;

public class Sringfuction1 {

	public static void main(String[] args) {
		
			String s1="Venkatesh";  		
			String s2="Venkatesh";  
			String s3="Vivek";  			
	        
			System.out.println(s1.compareTo(s2));  
			System.out.println(s1.compareTo(s3));	 
			System.out.println(s3.compareTo(s1));

		// TODO Auto-generated method stub

	}

}
