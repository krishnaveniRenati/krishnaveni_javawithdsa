package javaexerciseprogram;

public class Strings {

	public static void main(String[] args) {
		 String s="Sachin";
		   System.out.println(s.startsWith("Sa"));//true
		   System.out.println(s.endsWith("E"));
		 }

		// TODO Auto-generated method stub

	}


