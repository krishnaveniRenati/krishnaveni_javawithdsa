package javapraticeprogram;

public class Conditional {

		public static void main(String[] args) {
			String classification ="Employee";
			String Teacher = "Language";
			int marks = 80;
			String result;
			int a =10;
			int b =5;
			
			if (a==b)
			{
				System.out.println("Pass");
			}
			else
			{
				System.out.println("Fail");
			}
		}
}
		
				




