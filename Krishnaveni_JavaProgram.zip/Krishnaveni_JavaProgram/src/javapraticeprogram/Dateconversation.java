package javapraticeprogram;

public class Dateconversation {

	public static void main(String[] args) {
		long a=45;
		int b;
		b=(int)a;
		System.out.println(a);
		System.out.println(b);
		// TODO Auto-generated method stub

	}

}
