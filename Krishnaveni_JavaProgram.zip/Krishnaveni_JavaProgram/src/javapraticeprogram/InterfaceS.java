package javapraticeprogram;

public class InterfaceS {  
		void print() {
		}  
	} 

