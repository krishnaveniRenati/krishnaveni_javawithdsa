package javapraticeprogram;

public class SBI {
	public static void main(String[] arag){
		System.out.println("state bank of India");
		System.out.println("----------------");
		System.out.println("SBI");
		
		
	}

	public String getRateOfInterest() {
		// TODO Auto-generated method stub
		return null;
	}

}
