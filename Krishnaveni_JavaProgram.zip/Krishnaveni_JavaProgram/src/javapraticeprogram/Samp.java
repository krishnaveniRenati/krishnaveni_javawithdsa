package javapraticeprogram;

public class Samp {

	public static void main(String[] args) {
	
			 void method() throws Exception
			 {  
				 //System.out.println("Inside called method");
				 int a = 50 / 0; 
				 System.out.println(a);
			 }  
			}  

			class Exception4{  
			   public static void main(String args[]) throws Exception{ 
				try{
					Samp obj = new Samp();  
					obj.method();  
				} 
				catch(Exception e)
				{System.out.println("Exception handled");}
				
			    System.out.println("Inside main function"):

	public void method() {
		// TODO Auto-generated method stub
		
	}

}
