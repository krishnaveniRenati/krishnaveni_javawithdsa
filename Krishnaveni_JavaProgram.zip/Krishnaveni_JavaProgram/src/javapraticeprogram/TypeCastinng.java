package javapraticeprogram;

public class TypeCastinng {

	public static void main(String[] args) {
		double a=45.9;
		byte b;
		b=(byte)a;
		System.out.println(a);
		System.out.println(b);
		
		// TODO Auto-generated method stub

	}

}
