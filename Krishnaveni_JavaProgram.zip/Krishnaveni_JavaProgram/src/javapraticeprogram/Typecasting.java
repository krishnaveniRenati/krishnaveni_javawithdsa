package javapraticeprogram;

public class Typecasting {
	

}
