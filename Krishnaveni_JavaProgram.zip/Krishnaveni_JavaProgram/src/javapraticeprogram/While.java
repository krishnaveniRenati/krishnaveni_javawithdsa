package javapraticeprogram;

public class While {
	public static void main(String[] args) {
		int i=3;
			while(i<5) 
			{
	System.out.println(i);
	}
		}
	}	