package javapraticeprogram;

public class data {
	public static void main(String[] args) {
	String x = "Hello ";     //STRING Variable Declaration
	char y = 'c';
	System.out.println("enter the values of"+x);
	System.out.println(y);

}
}

