package javapraticeprogram;

public class doloop {

}
