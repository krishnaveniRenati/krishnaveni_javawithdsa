package javapraticeprogram;

public class variablevalu {
	    public static void main(String[] args) {
	        // Declare and initialize variables
	        int x = 10;
	        String name = "Krishna";
	        		System.out.println("valu of x: "+x);
	        System.out.println("Name+ " +name);
	      
}
}