package javaexerciseprogram;

public class Array4 {

	public static void main(String[] args) {
		String employeeName[] = {"V", "h"};
		
		int employeeId[] = new int[2];
		employeeId[0] = 1;
		employeeId[1] = 20;
		System.out.println("Hi"+" "+"Welcome");
		System.out.println(employeeName[0]+ " " +employeeId[0]);
		System.out.println(employeeName[1]+ " " +employeeId[1]);	
	}
}
