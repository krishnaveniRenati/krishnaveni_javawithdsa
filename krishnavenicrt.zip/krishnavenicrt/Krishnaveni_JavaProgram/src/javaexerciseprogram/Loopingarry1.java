package javaexerciseprogram;

public class Loopingarry1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Single dimensional array
		int a[]= {4,7,5,6};
		//2-Dimensional Array
		int []x[]= {{1,2},{3,4,5,6},a};
		int y[][]	= x;
		System.out.println(y[2][1]);}


		// TODO Auto-generated method stub

	}

