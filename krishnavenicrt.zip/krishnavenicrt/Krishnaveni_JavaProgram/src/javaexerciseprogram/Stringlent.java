package javaexerciseprogram;

public class Stringlent {

	public static void main(String[] args) {
		String s="Sachina";
		   System.out.println(s.length());//6
		  }}

		// TODO Auto-generated method stub

