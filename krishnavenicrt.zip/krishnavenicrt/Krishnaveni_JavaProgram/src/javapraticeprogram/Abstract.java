package javapraticeprogram;

public abstract class Abstract {

}
