package javapraticeprogram;

public class Boolean {
	public static void main(String[] args) {
		String x = "Hello World"; 
		boolean	e = true;
		System.out.println("enter the values of"+x);
		System.out.println(e);
		}
}