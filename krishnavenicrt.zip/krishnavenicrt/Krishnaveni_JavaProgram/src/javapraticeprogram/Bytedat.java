package javapraticeprogram;

public class Bytedat {
	public static void main(String[] args) {
	String x = "Hello";     //STRING Variable Declaration"
	byte f = -100;
	System.out.println("enter the values of"+x);
	System.out.println(f);

}
}

