package javapraticeprogram;

public class DoWhile {
	public static void main(String[]args) {
		int i=1;
		do {
			System.out.println("hellowelcome");
			i++;
		}
		while(i<=5);
	}

}
