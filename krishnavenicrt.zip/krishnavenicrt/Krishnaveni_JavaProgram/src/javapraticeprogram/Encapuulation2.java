package javapraticeprogram;

public class Encapuulation2 {

	public static void main(String[] args) {
		{

		 
				Encapsulation1 obj = new Encapsulation1();
			    
				obj.setName("krishnaveni");
			    System.out.print("Name : " + obj.getName());  //vivek
			}

		}

		
		// TODO Auto-generated method stub

	}
