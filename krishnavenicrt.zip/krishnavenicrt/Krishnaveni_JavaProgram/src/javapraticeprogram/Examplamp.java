package javapraticeprogram;

public class Examplamp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
