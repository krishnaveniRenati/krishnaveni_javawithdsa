package javapraticeprogram;

	public staticvoidmain(String[] args) {
		public static void main1(String[] args) {
			javapraticeprogram.SBI obj; 
			
			obj=new SBI();  
			System.out.println("SBI Rate of Interest: "+obj.getRateOfInterest()); 
			
			obj=new javapraticeprogram.SBI();  
			System.out.println("ICICI Rate of Interest: "+obj.getRateOfInterest());
			
			obj=new javapraticeprogram.SBI();  
			System.out.println("HDFC Rate of Interest: "+obj.getRateOfInterest());
		}


		// TODO Auto-generated method stub

	}

