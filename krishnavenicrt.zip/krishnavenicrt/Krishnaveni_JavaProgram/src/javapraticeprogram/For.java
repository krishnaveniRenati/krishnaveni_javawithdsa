package javapraticeprogram;

public class For {

}
