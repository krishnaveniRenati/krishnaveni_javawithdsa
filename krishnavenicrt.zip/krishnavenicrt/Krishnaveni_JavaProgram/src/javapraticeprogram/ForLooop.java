package javapraticeprogram;

public class ForLooop {

	public static void main(String[] args) {
		int i;
		int n=5;
		for(i=1;i<=n;i++)
		{
			System.out.println(i);
		}
		// TODO Auto-generated method stub

	}

}
