package javapraticeprogram;

public class HDFC {

	public static void main(String[] args) {
		System.out.println("HDFC Bank");
		System.out.println("Housing Development Coration");
		// TODO Auto-generated method stub

	}

}
