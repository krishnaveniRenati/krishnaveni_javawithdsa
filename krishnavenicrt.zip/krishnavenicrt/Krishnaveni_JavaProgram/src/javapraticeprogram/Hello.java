package javapraticeprogram;

public class Hello {

	public static void main(String[] args) {
		System.out.println("hai welcome to  krishnaveni");
		System.out.println("hello welcome to  krishnaveni");
		System.out.println("hai welcome to  krishnaveni");
		System.out.println("hello welcome to krishnaveni");

	}

}



