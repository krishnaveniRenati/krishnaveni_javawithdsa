package javapraticeprogram;

public class ICICIextendsBankp {
		float getRateOfInterest()
		{
			return 7.5f;
		} 
	}

