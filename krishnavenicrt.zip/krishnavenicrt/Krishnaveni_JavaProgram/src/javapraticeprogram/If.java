package javapraticeprogram;

public class If {

	public static void main(String[] args) {
		int x=5;
		if(x>10) {
			System.out.println("x is greater than 10");}
			else {
				System.out.println("x is less than equal to 10");}
				
			}
		}
	
		
