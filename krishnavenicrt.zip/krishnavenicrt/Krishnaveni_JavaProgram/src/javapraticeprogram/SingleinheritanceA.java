package javapraticeprogram;

public class SingleinheritanceA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
