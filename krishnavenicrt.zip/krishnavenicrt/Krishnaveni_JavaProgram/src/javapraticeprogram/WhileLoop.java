package javapraticeprogram;

public class WhileLoop {

}
