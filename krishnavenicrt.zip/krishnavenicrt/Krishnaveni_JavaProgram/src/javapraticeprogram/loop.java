package javapraticeprogram;

public class loop {
	public static void main(String[] args) {
		for(int i=1;i<5;i++);{
			int i = 10;
			System.out.println("number:" +i );
		}
	}
}
		
