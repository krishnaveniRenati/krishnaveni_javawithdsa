package arrays;

public class Arrays_Print {

	public static void main(String[] args) {
	
		int a[]=new int[5];//declaration and instantiation  
		a[0]=100;//initialization  
		a[1]=205;  
		a[2]=709;  
		a[3]=402;  
		a[4]=506;  
		//traversing array  
		for(int i=0;i<a.length;i++)//length is the property of array  
		System.out.println(a[i]);  
	}

}
