package Java;

public class ICICI extends BankP {
	float getRateOfInterest()
	{
		return 7.4f;
	} 
}
