package Java;

interface InterfaceS1 {
	void print1();
}
