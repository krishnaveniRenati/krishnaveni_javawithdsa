package Java;

public class MainFunction {
	public static void main(String[] args) {
		
		ImplementsS obj = new ImplementsS();  
		obj.print(); 
		obj.print1(); 
		 
	}
}
