package Java;

import java.sql.*;

public class SPDemo1 {
public static void main(String[] args) throws ClassNotFoundException, SQLException {

Class.forName("com.mysql.cj.jdbc.Driver");
Connection con = DriverManager.getConnection("jdbc:mysql://localhost/java", "root", "Root");
CallableStatement cStmt = con.prepareCall("{call Employees(?,?)}");
			
//cStmt.setString(1, "Jaffer");
cStmt.registerOutParameter(2, Types.VARCHAR);
//cStmt.registerOutParameter(3, Types.INTEGER);
			
boolean hadResults = cStmt.execute();
//System.out.println("| BankName | AccNo |");
		
while(hadResults) {
ResultSet rs = cStmt.getResultSet();
while(rs.next()){
    System.out.println("");
	int id  = rs.getInt(1);
    String name = rs.getString(2);
    //float salary = rs.getFloat(3);

    //Display values
    System.out.print(id + "\t");
    System.out.print(name + "\t");
    //System.out.print(salary + "\t");
 }
hadResults = cStmt.getMoreResults();
}
					
cStmt.close();
}
}

