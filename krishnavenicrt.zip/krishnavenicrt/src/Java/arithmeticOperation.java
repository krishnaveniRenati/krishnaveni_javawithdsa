package Java;

public class arithmeticOperation 
{
	public int sum(int a, int b) 
	{
		int c = a + b;
		return c;
	}

}
